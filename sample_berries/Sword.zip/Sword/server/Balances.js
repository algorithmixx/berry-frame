"use strict";

const Logger 	= require("berry-frame/utils/Logger.js").Logger;
const StripPlayer	= require("./StripPlayer.js").StripPlayer;

var app;

class Balances extends StripPlayer {
	// use the Z VALUE of the motion signal to simulate a tubular level (Wasserwaage)

	constructor(theApp,delay,rounds,steps) {
		super(theApp,delay,rounds,steps);
		this.motion = theApp.hardware.elms["motionA"];
		app=theApp;
	}
	
	step(values) {	
		// one LED step ~ 2 degrees of deviation
	
		var my=app.player;
		if (!super.step(values,my.motion)) return;	// check for begin / end
		
		app.stepTimer = setTimeout(function() {
			// get an array of x,y,z with each value between -180 and +180

			my.leds.fill(0,0,0);

			var pos = my.motion.dev.getValue();
			var l = my.len/4-0.5*(90-(pos[2] % 180));
			if 		(l<0 || l>=my.len/2) {
				if (l<0) l=0;
				else l = Math.round(my.len/2);
				my.leds.setColor(l,[100,0,0]);
			}
			else {
				l=Math.round(l);
				my.leds.setColor(l,[20,150,20]);
			}
			my.leds.update(my.step); 	// update LEDs and let us call back with the changed state
			app.server.broadcastState(my.motion,"MPU6500",pos);
		}, my.delay );
	}
}

// =========================================================================================================

module.exports.Balances			= Balances;
