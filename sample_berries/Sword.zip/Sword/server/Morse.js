﻿"use strict";

const Logger 		= require("berry-frame/utils/Logger.js").Logger;
const StripPlayer	= require("./StripPlayer.js").StripPlayer;

var app;

class Morse extends StripPlayer {
	// Show Morse encoding of a text piece by piece.
	// dots and dashes are represented by different colors
	// unknown symbols are represented by a single LED in a third color
	// letters are separated by one dark LED
	// words by two, line breaks by three dark LEDs

	constructor(theApp,text,size) {
		// show the Morse encoding of a text
		// size is the limit of symbols which can be shown in one step
		// we try to break long messages at line or word boundaries
		
		super(theApp,1000,0,100);								// up to 100 message piecess
		this.size		= size || 20;							// limit for size of message pieces
		this.speakers	= theApp.hardware.elms["speakers"];		// for sound output
		app 			= theApp;
		
		Logger.log("Morse        input = "+text);

		// table of morse symbols
		var morse = {
			a	: ".-",			b	: "-...",		c	: "-.-.",		d	: "-..",		e	: ".",			f	: "..-.",
			g	: "--.",		h	: "....",		i	: "..",			j	: ".---",		k	: "-.-",		l	: ".-..",
			m	: "--",			n	: "-.",			o	: "---",		p	: ".--.",		q	: "--.-",		r	: ".-.",
			s	: "...",		t	: "-",			u	: "..-",		v	: "...-",		w	: ".--",		x	: "-..-",
			y	: "-.--",		z	: "--..",		"ä"	: ".--.-",		"ö"	: "---.",		"ü"	: "..-.",		"ß"	: "...--..",
			"1"	: ".----",		"2"	: "..---",		"3"	: "...--",		"4"	: "....-",		"5"	: "-----",
			"6"	: "-....",		"7"	: "--...",		"8"	: "---..",		"9"	: "----.",		"0"	: "-----",
			"."	: ".-.-.-",		","	: "--..--",		";"	: "-.-.-.",		"?"	: "..--..",		"-"	: "-....-",
			"_"	: "..--.-",		"("	: "-.--.",		")"	: "-.--.-",		"'"	: ".----.",		"+"	: ".-.-.",
			"/"	: "-..-.",		"@"	: ".--.-.",
		};

		// remove trailing/leading spaces, ignore multiple spaces, convert text to lower case and encode it
		// put special symbols at boundaries of letters (" "),words("w"),lines("l") and at the end("e") of the text
		var code = "";
		for (var letter of text.trim().replace(/ +/g,' ').toLowerCase().split('')) {
			if 		(letter==" ") 		code +="W ";			// word separation
			else if (letter=="\n")		code +="L  "; 			// line separation
			else {
				var s = morse[letter];
				if (typeof s =="undefined") code += "?";		// unknown character
				else						code += s;			// known character
				code+=" "; 										// letter separation
			}
		}
		code+="E";											// end marker
		Logger.log("Morse        code  = "+code);

		// color assignment for each symbol of an encoded date representation
		this.symbolColor={
			".": 	[  0,   0, 255],	// blue
			"-": 	[ 255,  0,   0],	// red
			" ": 	[  0,   0,   0],	// dark space for separation of symbols
			"L": 	[  0,   0,   0],	// dark space for separation of words
			"W": 	[  0,   0,   0],	// dark space for separation of lines
			"?": 	[ 255,  0, 255],	// violet for unknown characters			
		};

		// now we have a string like this:
		// input = "Hello World", code  = ".... . .-.. .-.. --- W .-- --- .-. .-.. -.. E"
		
		this.code	= code;
		this.pos	= 0;	// the current position within code 
		this.delay	= 1;	// the first part of the encoded text can be shown immediately
	}
	
	step(values) {	
		// split the encoded text into pieces which can be shown on the LED strip
		// i.e. use max. "size" LEDs in one step
		// calculate the reading time needed depending on the number of symbols shown
		
		var my=app.player;

		if (!super.step(values,true)) return; // check for begin / end of stepping
				
		// end of text reached ?
		if (my.code[my.pos]=="E") {
			app.stepTimer=false;
			return;
		}

		// search for word boundary
		var lb=my.pos, wb=my.pos, cb=my.pos;		// latest boundary below size (line, word, char)
		for (var b=my.pos; my.code[b]!="E"; b++) {
			if (b-my.pos>my.size) break;			// size limit reached
			if 		(my.code[b]=="L") lb=b;			// store line boundary
			else if (my.code[b]=="W") wb=b;			// store word boundary
			else if (my.code[b]==" ") cb=b;			// store char boundary
		}
		var end = lb;								// ideally take latest line boundary
		if (end==my.pos) end = wb;					// fall back to latest word boundary
		if (end==my.pos) end = cb;					// fall back to latest char boundary
		if (end==my.pos) return;					// size is too short for a single letter, should never occur
		
		// set the LED colors
		my.leds.fill(0,0,0);	// reset all LEDs
		var n=0;
		for (var b=my.pos;b<end;b++) {
			my.leds.setColor(n,my.symbolColor[my.code[b]]);		// use color of the resp. symbol
			n++;
		}
		
		// calculate time needed to read the code
		var delay= (end-my.pos) * 400;				// 400 msec per symbol, which is quite slow
		
		// advance position and skip boundary symbols (except "E")
		var begin=my.pos;
		my.pos=end;
		while(my.code[my.pos]=="W" || my.code[my.pos]=="L" || my.code[my.pos]==" ") my.pos++;

		// change lED strip and set delay for next step
		my.stepTimer = setTimeout(function() {
			my.delay = delay;						// set next delay
			my.leds.update(my.step);				// update LEDs and let us call back
			my.speakers.dev.playMorse(my.code.substr(begin,end-begin),150);
		}, my.delay );
	}
}

// =========================================================================================================

module.exports.Morse 		= Morse;
