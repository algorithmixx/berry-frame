"use strict";

const Logger 	= require("../../berry/utils/Logger.js").Logger;
const isMissing = require("../../berry/utils/Logger.js").isMissing;
const isPresent = require("../../berry/utils/Logger.js").isPresent;

var app;

class StripPlayer {
	constructor(theApp,delay,rounds,steps) {
		app				= theApp;							// a reference to the appObject
		this.delay		= delay; 							// duration of a step (milliseconds)
		this.strip		= app.hardware.elms['stripA'];		// the hardrware element we want to control
		this.leds		= this.strip.dev;					// the hardware device (Ws2801)
		this.len		= this.strip.numLEDs;				// number of LED triples		
		this.maxSteps	= rounds*this.len+steps;			// number of steps (full cycles)
		this.isPlaying	= false;							// whether a strip demo is running or not
		this.stepTimer	= false;							// reference to active step timer
	}
	
	start() {
		// reset step number
		this.stepNr 	= -2;
		this.round		=  0;
		this.isPlaying	= true;
		this.step();
	}
	
	step(values,requiredObj) {
		// handles begin (=clear strip) and end of the prog
		// the specific processing happens in the step() method of the sub class
		// requiredObj must not be "undefined" to allow continuation

		var my=app.player;		
		// Logger.log("Sword        step #"+my.stepNr);
		
		// publish current strip state
		if (my.stepNr >=-1 && isPresent(values)) {
			app.server.broadcastState(my.strip,"WS2801",values);
		}

		my.stepNr++;  										// advance step
		if (my.StepNr>0 && my.stepNr%my.len==0) my.round++;	// and round

		if (my.stepNr==-1) {								// initially clear all LEDs
			my.leds.clear(my.step);
			return false;
		}

		if (my.stepNr>=my.maxSteps || !requiredObj) {		// end of prog
			my.isPlaying=false;
			if (app.onFinished) app.onFinished(my);
			return false;
		}
		
		return true;		
	}
	
	stop() {
		if (app.stepTimer!==false) {
			clearTimeout(app.stepTimer);
			app.stepTimer=false;
		}
		if (app.player.isPlaying) {
			app.player.stepNr=app.player.maxSteps+1;
			app.player.isPlaying=false;
		}
	}
}

class RedDotRunning extends StripPlayer {
	
	step(values) {	
		// let a red dot run around, followed by a trace of dark blue/green lights
	
		var my=app.player;
		if (!super.step(values,true)) return;	// check for begin / end
		
		// change the current LED and the one ahead of it
		app.stepTimer= setTimeout(function() {
			my.leds.setColor(my.stepNr % my.len, [0,50,20]);		// blue/green
			my.leds.setColor((my.stepNr+1) % my.len, [255,50,50]);	// red 
			my.leds.update(my.step); 	// update LEDs and let us call back
		}, my.delay );
	}
}

class HiddenMessage extends StripPlayer {

	constructor(app,delay,rounds,steps) {
		super(app,delay,rounds,steps);
		this.text= [
			"x   x   x   x     x      xxx        x   x xxxx  x     xxxxx   x         ",
			"x   x  x x  x     x     x   x       x   x x     x       x     x         ",
			"xxxxx x   x x     x     x   x       x   x xxx   x       x     x         ",
			"x   x xxxxx x     x     x   x       x x x x     x       x               ",
			"x   x x   x xxxxx xxxxx  xxx         x x  xxxx  xxxxx   x     x         ",
		];
		
	}
	
	step(values) {	
		// let symmetric dots wander to the tip
	
		var my=app.player;
		if (!super.step(values,true)) return;	// check for begin / end

		app.stepTimer = setTimeout(function() {
			// use a blue/green random color for the current LED
			my.leds.fill(0, 0, 0);
			var x = my.stepNr % my.text[0].length;
			for (var y=0;y<my.text.length;y++) {
				my.leds.setColor(y+3,my.text[my.text.length-1-y].substr(x,1)==" " ? [0,0,0] : [x%6?50:0,x%6?0:50,x%72?0:100]);
			}
			my.leds.update(my.step); 	// update LEDs and let us call back
		}, 500 );
	}
}

class CirclingColors extends StripPlayer {
	
	step(values) {	
		// let color waves circle around
	
		var my=app.player;
		if (!super.step(values,true)) return;	// check for begin / end
		
		app.stepTimer = setTimeout(function() {
			// change all values according to three different sine wave functions
			for (var l=0;l<my.len;l++) {
				my.leds.setColor(l,[
					127+127*Math.sin(2*Math.PI/my.len*     (my.stepNr-l)),
					127+127*Math.sin(2*Math.PI/my.len*3.1 *(my.stepNr-l)),
					127+127*Math.sin(2*Math.PI/my.len*0.25*(my.stepNr-l)),			
				]);
			}
			my.leds.update(my.step); 	// update LEDs and let us call back with the changed state
		}, my.delay );
	}
}


// =========================================================================================================
module.exports.StripPlayer 		= StripPlayer;
module.exports.RedDotRunning	= RedDotRunning;
module.exports.HiddenMessage	= HiddenMessage;
module.exports.CirclingColors	= CirclingColors;
