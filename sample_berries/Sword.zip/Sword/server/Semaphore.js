"use strict";

const Logger 	= require("berry-frame/utils/Logger.js").Logger;
const StripPlayer	= require("./StripPlayer.js").StripPlayer;

var app;

class Semaphore extends StripPlayer {
	// use the z-axis to change color between red, yellow, green

	constructor(theApp,delay,rounds,steps) {
		super(theApp,delay,rounds,steps);
		app 		= theApp;
		this.motion = app.hardware.elms["motionA"];
		this.size	= Math.floor(this.len / 6);
	}
	
	step(values) {	
		// 0 is in the middle, x= blue, y=red
	
		var my=app.player;
		if (!super.step(values,my.motion)) return;	// check for begin / end
		
		app.stepTimer = setTimeout(function() {
			my.leds.fill(0,0,0);
			// get an array of x,y,z with each value between -180 and +180
			var pos = my.motion.dev.getValue();
			
			if (pos[2]<=30) {
				for (var l=0;l<my.size;l++) {
					my.leds.setColor(l,[0,200,0]);
				}
			}
			if (pos[2]>30 && pos[2]<= 60) {
				for (var l=0;l<my.size;l++) {
					my.leds.setColor(my.size+l,[150,150,0]);
				}
			}
			if (pos[2]>60) {
				for (var l=0;l<my.size;l++) {
					my.leds.setColor(my.size*2+l,[200,0,0]);
				}
			}

			my.leds.update(my.step); 	// update LEDs and let us call back with the changed state
			// app.server.broadcastState(my.motion,"MPU6500",pos);
		}, my.delay );
	}
}


// =========================================================================================================

module.exports.Semaphore		= Semaphore;
