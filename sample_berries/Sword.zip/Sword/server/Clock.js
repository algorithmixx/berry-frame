"use strict";

const Logger 		= require("berry-frame/utils/Logger.js").Logger;
const StripPlayer	= require("./StripPlayer.js").StripPlayer;

var app;

class Clock extends StripPlayer {
	// simulate a clock,
	// display the current time   HH MM SS   
	// in various encodings: Roman / BCD / Dual / Tri / Tetra / SecBin
	

	constructor(theApp,encoding,steps) {
		// show the encoding for the given number of steps
		
		Logger.log("Clock        starting with encoding="+encoding);
		
		super(theApp,1000,0,steps);
		app 			= theApp;
		
		// use the given encoding or the next one (if none given)
		var encodings = ["Roman","BCD","Dual","Tri","Tetra","SecBin"];	
		if (!encoding || encodings.indexOf(encoding)<0) {	// missing or invalid
			if (!Clock.lastEncoding) encoding=encodings[0];	// we have no history
			else {											// take next in sequence
				encoding=encodings[(encodings.indexOf(Clock.lastEncoding)+1)%encodings.length];
			}
		}
		this.encoding = Clock.lastEncoding = encoding;	// use encoding and store into history

		// roman numbers (0..59)   19:04:15 ==> "xix iv xiv"
		this.roman=[
			"","i","ii","iii","iv","v","vi","vii","viii","ix",
			"x","xi","xii","xiii","xiv","xv","xvi","xvii","xviii","xix",
			"xx","xxi","xxii","xxiii","xxiv","xxv","xxvi","xxvii","xxviii","xxix",
			"xxx","xxxi","xxxii","xxxiii","xxxiv","xxxv","xxxvi","xxxvii","xxxviii","xxxix",
			"xl","xli","xlii","xliii","xliv","xlv","xlvi","xlvii","xlviii","xlix",
			"l","li","lii","liii","liv","lv","lvi","lvii","lviii","lix",
		];

		// binary coded decimal (per digit) 19:04:15 ==> "00011001 00000100 00010101" 
		this.bcd=[]; for(var d=0;d<10;d++) this.bcd.push(d.toString(2).padStart(4,"0"));
		
		// pure binary (0..59)    19:04:15 ==> "010011 000100 001111"
		this.bin=[]; for(var t=0;t<60;t++) this.bin.push(t.toString(2).padStart(6,"0"));

		// number system based on triples (0..59)   19:04:15 ==> "0201 0011 0120"
		this.tri=[]; for(var t=0;t<60;t++) this.tri.push(t.toString(3).padStart(4,"0"));

		// number system based on quadruples (0..59)   19:04:15 ==> "0103 0010 0033"
		this.tetra=[]; for(var t=0;t<60;t++) this.tetra.push(t.toString(4).padStart(3,"0"));

		// total number of seconds binary      19:04:15 ==> 68655 ==> "10000110000101111"
		// HH*3600+MM*60+SS
		
		// color assignment for each symbol of an encoded date representation
		this.symbolColor={
			" ": 	[  0,  0,  0],	// dark space for separation of symbols
			"0": 	[ 30, 30, 30],	// dark light
			"1": 	[  0,150,  0],	// green
			"2": 	[150,  0,  0],	// red
			"3": 	[  0,  0,150],	// blue
			"i":	[  0,200,  0],	// green		
			"v":	[  0,  0,200],	// blue
			"x":	[200,200,  0],	// yellow
			"l":	[  0,200,200],	// cyan
		};
	}
	
	step(values) {	
		// change LED strip every second according to the chosen encoding

		var my=app.player;
		if (!super.step(values,true)) return;	// check for begin / end of stepping
		
		// the following function will be called after a delay of ~ 1 second (1000 msec)
		// using a fixed value of exactly 1000 msecs would lead to a problem, because
		// processing the commands below needs some time; this may be 2..10 msecs on a PC
		// but it can be significantly more on a slow Raspi (old models).
		// As a consequence our clock would SKIP ONE SECOND every now and then.
		// To compensate for this effect we calculate the necessary delay as the difference
		// between "now" and the _next_absolute_check_point in time 
		// (which we wish to be 100 msec after the second has changed).
		
		var now = new Date().getTime();
		
		// get current time and compose textual representation according to encoding

		var now=new Date();	// get current time
		var nowText="";
		if 		(my.encoding=="Roman") {		//	19:04:15 ==> "xix iv xiv"
			nowText=my.roman[now.getHours()]+" "+my.roman[now.getMinutes()]+" "+my.roman[now.getSeconds()];
		}
		else if (my.encoding=="BCD") {			//	19:04:15 ==> "00011001 00000100 00010101" 
			if (now.getHours()  <10) nowText+=my.bcd[0]; 
			else nowText+=my.bcd[Math.floor(now.getHours()  /10)];	nowText+=my.bcd[now.getHours()  %10]; 
			nowText+=" ";
			if (now.getMinutes()<10) nowText+=my.bcd[0]; 
			else nowText+=my.bcd[Math.floor(now.getMinutes()/10)];	nowText+=my.bcd[now.getMinutes()%10]; 
			nowText+=" ";
			if (now.getSeconds()<10) nowText+=my.bcd[0]; 
			else nowText+=my.bcd[Math.floor(now.getSeconds()/10)];	nowText+=my.bcd[now.getSeconds()%10];
		}
		else if (my.encoding=="Dual") {   		//	19:04:15 ==> "010011 000100 001111"
			nowText=my.bin[now.getHours()]+" "+my.bin[now.getMinutes()]+" "+my.bin[now.getSeconds()];
		}
		else if (my.encoding=="Tri") {			//	19:04:15 ==> "0201 0011 0120"
			nowText=my.tri[now.getHours()]+" "+my.tri[now.getMinutes()]+" "+my.tri[now.getSeconds()];
		}
		else if (my.encoding=="Tetra") {		//	19:04:15 ==> "0103 0010 0033"
			nowText=my.tetra[now.getHours()]+" "+my.tetra[now.getMinutes()]+" "+my.tetra[now.getSeconds()];
		}
		else if (my.encoding=="SecBin") {		//	19:04:15 ==> 68655 ==> "10000110000101111"
			nowText=((now.getHours()*3600+now.getMinutes()*60+now.getSeconds()) >>> 0).toString(2);
		}

		// set the LED colors
		my.leds.fill(0,0,0);	// reset all LEDs
		var n=0;
		for (var letter of nowText.split('')) {
			my.leds.setColor(n,my.symbolColor[letter]);		// use color of the resp. symbol
			n++;
		}
		// transfer LED settings to the hardware and publish the new values
		my.leds.update(function(values) { 
			app.server.broadcastState(my.strip,"WS2801",values);
		});
		
		// call ourselves again after ~ 1 second
		var delay = 1100 - (now%1000);
		app.stepTimer = setTimeout(my.step, delay );

		// show textual representation in the server log , also show the current delay;
		// on a fast PC the delay will oscillate around 997 msec; on a Raspi it can be around 950 msecs
		Logger.log(nowText + "    ("+delay+")");

	}
}
Clock.lastEncoding=false;	// remember the last encoding used, so we can cycle through the possible values

// =========================================================================================================

module.exports.Clock 		= Clock;
