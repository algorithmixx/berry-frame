﻿"use strict";

const Logger 			= require("berry-frame/utils/Logger.js").Logger;
const isMissing	 		= require("berry-frame/utils/Logger.js").isMissing;
const isPresent 		= require("berry-frame/utils/Logger.js").isPresent;
const App 				= require("berry-frame/server/App.js").App;
const StripPlayer		= require("./StripPlayer.js").StripPlayer;
const RedDotRunning		= require("./StripPlayer.js").RedDotRunning;
const HiddenMessage		= require("./StripPlayer.js").HiddenMessage;
const CirclingColors	= require("./StripPlayer.js").CirclingColors;
const Clock				= require("./Clock.js").Clock;
const Balances			= require("./Balances.js").Balances;
const Semaphore			= require("./Semaphore.js").Semaphore;
const Morse				= require("./Morse.js").Morse;

var app;

// =========================================================================================================

class Sword extends App {
	/*
		Sword is a Berry plugin module which represents an LED strip to be held by a grip.
		It is not meant for fighting - it is rather like a szeptre / wand. It has a motion sensor,
		a single button and an audio unit with microphone and speakers.
		
		This class registers its methods at the hardware elements it wants to control.
	*/
	
	constructor(hardware,silent) {
		super(hardware,silent);
	}

	init() {
		app = this.hardware.appObject;	 // a reference to ourselves
		this.player = null;

		this.waitForPlayerStop=-1;	// number of tries to wait until a potentially running demo has stopped
		
		this.shuttingDown=false;		
	}
	
	onStart(onStarted) {
		// play initial standard pattern or call onStarted() instead
		
		Logger.info("Sword        starting");

		if (onStarted) onStarted();
		else this.play(function(){app.off("off");},"circling colors");
	}
	
	onStop(onStopped) {
		// stop running tasks
		
		Logger.info("Sword        stopping");
		if (app.player) app.player.stop();
		this.shuttingDown=true;
		if (onStopped) onStopped();
	}
	
	onButtonSpeakerPressed(id,value) {
		Logger.log("Sword        "+id+" pressed");
		if (app.player && app.player.isPlaying) {
			app.player.stop();
			setTimeout(app.off, 250);
		}
		else {
			app.play(null,"morse","Hello World");
		}
	}
	
	onDownUpButBlack(but,state) {
		Logger.log("Sword        testing "+but.id+" ("+state+") for long press");
		if 		(but.id=="butBlack" && state==1) app.butBlackDownAt=new Date().getTime();
		else if (but.id=="butBlack" && state==0 && ((new Date().getTime())-app.butBlackDownAt)>3000) {
			// the black button was held down for more than 3 seconds;
			Logger.info("Sword        shutdown requested (black button was pressed for more than 5 seconds");
			app.shuttingDown=true;
			if (app.player && app.player.isPlaying) {
				Logger.info("Sword        stopping active player");
				app.player.stop();
				setTimeout(function() { Logger.info("Sword        switching off LED strip"); app.off("off"); }, 250);
				setTimeout(function() {	Logger.info("Sword        shutting down"); app.server.shutDown();} ,350);
			}
			else {
				Logger.info("Sword        switching off LED strip"); 
				app.off("off");
				setTimeout(function() {	Logger.info("Sword        shutting down"); app.server.shutDown();} ,100);
			}
		}
	}

	onButtonPressed(but) {
		// play a random demo

		// ignore any further requests if we are in the process of shutdown
		if(app.shuttingDown) return;
		
		// the button id tells us what to do
		var id = but.id;
		
		// the blue button acts like random
		if (id=="butBlue") id=[
			"off",
			"rgbw",
			"toggleLedA",
			"toggleLedSpkr",
			"music",
			"red dot running",
			"hidden message",
			"cicling colors",
		][Math.floor(Math.random()*8)];

		Logger.log("Sword        Button "+but.id+" pressed, playing "+id);
		
		if (app.waitForPlayerStop>0) --app.waitForPlayerStop; // remaining tries
		if (app.player && app.player.isPlaying && app.waitForPlayerStop>=0) {
			// stop current player,wait until it has finished
			app.player.stop();
			// try again after 250 msec
			setTimeout(function() { app.onButtonPressed(but); },250 );
			return;
		}
		
		if 		(id=="off"	) 			app.off("off");
		else if (id=="rgbw"	) 			app.rgbw("rgbw");
		else if (id=="toggleLedA") 		app.hardware.elms['ledA'].dev.toggle();
		else if (id=="toggleLedSpkr")	app.hardware.elms['ledSpkr'].dev.toggle();
		else if (id=="music")			app.hardware.elms['speakers'].dev.play(app.hardware.elms.music.prog);
		else if (id=="butRed")			app.play(null,"clock");
		else if (id=="butGreen")		app.play(null,"circling colors");
		else if (id=="butYellow")		app.play(null,"semaphore");
		else if (id=="butBlack")		{ /* app.play(null,"balances"); */ }
		else 							app.play(null,id);
	}

	shutdown(id,value) {
		Logger.info("Sword        Shutdown: "+id+", "+value);
	}
	
	show(onFinished,pattern) {
		if		(pattern=="off"	) this.off("off");
		else if (pattern=="rgbw") this.rgbw("rgbw");
	}
	
	off(values) {
		// switch strip off (all LEDS becoming dark)

		var strip	= app.hardware.elms['stripA'];
		if (values=="off") strip.dev.clear(app.off);	// will call us back with values==[0,..]
		else app.server.broadcastState(strip,"WS2801",values);
	}
	
	rgbw(values) {
		// create four sections (R,G,B,W) with increasing intensity

		if(app.shuttingDown) return;

		var strip	= app.hardware.elms['stripA'];
		var leds	= strip.dev;						// the hardware device (Ws2801)
		var len = strip.numLEDs - strip.numLEDs%4;
		var len4 = Math.round(len / 4);
		if (values=="rgbw") {
			for (var l=0;l<len;l++) {
				var q=Math.floor(l/len4);
				var r= (q==0 || q==3) ? Math.round((l%len4+1)/len4*255) : 0;
				var g= (q==1 || q==3) ? Math.round((l%len4+1)/len4*255) : 0;
				var b= (q==2 || q==3) ? Math.round((l%len4+1)/len4*255) : 0;
				strip.dev.setColor(l, [r,g,b]);
			}
			strip.dev.update(app.rgbw); 
		}
		else app.server.broadcastState(strip,"WS2801",values);
	}
	
	morse(onFinished,arg) {
		this.play(onFinished,"morse",arg);
	}
	
	play(onFinished,prog,arg) {
		// Change state of the LED strip step by step.
		// Create an instance of the desired StripPlayer sub class

		if(app.shuttingDown) return false;

		app.waitForPlayerStop=10;
		app.onFinished = onFinished;

		if (app.player && app.stepTimer) app.player.stop();
		
		Logger.log("Sword        starting to play '"+prog+"' for WS2801 led strip ..");
		if (prog=="red dot running") 	{
			app.player = new RedDotRunning(app,50,1,Math.floor(app.hardware.elms["stripA"].numLEDs/2));
			app.player.start();
		}
		else if (prog=="hidden message") 	{
			app.player = new HiddenMessage(app,100,50,0);
			app.player.start();
		}
		else if (prog=="circling colors") 	{
			app.player = new CirclingColors(app,20,1,15);
			app.player.start();
		}
		else if (prog.substr(0,6)=="clock ") 	{
			app.player = new Clock(app,prog.substr(6),100);
			app.player.start();
		}
		else if (prog=="clock") 	{
			// use a random encoding for 100 seconds
			app.player = new Clock(app,"",100);
			app.player.start();
		}
		else if (prog=="balances") 	{
			app.player = new Balances(app,50,0,200);
			app.player.start();
		}
		else if (prog=="semaphore") 	{
			app.player = new Semaphore(app,50,0,5000);
			app.player.start();
		}
		else if (prog=="morse") {
			app.player = new Morse(app,arg);
			app.player.start();
		}
		else {
			Logger.error("Sword: unknown play program '"+prog+"'");
			return false;
		}
		return true;
	}	
}
Sword.getApiDescription = function() {
	return [
		{	cmd:	"onButtonPressed",
			effect:	"plays a random demo"
		},
		{	cmd:	"play",
			effect:	"plays the selected demo program",
			args: [
				{name:"prog",	meaning:"the id of a program, can be one of [A,B,C,D,E]"},
			]
		},
	];
}

// =========================================================================================================
module.exports.Sword = Sword;
