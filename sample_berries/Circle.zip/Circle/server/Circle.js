"use strict";

const Logger 	= require("berry-frame/utils/Logger.js").Logger;
const isMissing = require("berry-frame/utils/Logger.js").isMissing;
const isPresent = require("berry-frame/utils/Logger.js").isPresent;
const App 		= require("berry-frame/server/App.js").App;

var app;

// =========================================================================================================

class Circle extends App {
	/*
		Circle provides additional methods for the circle hardware;
		the basic functionality of toggling an LED and its two neighbors is already
		covered by the hardware definition file		
	*/
	
	constructor(hardware,silent) {
		super(hardware,silent);
		
		// make instance available for functions which are invoked as callbacks
		app=this;
	}
	
	init() {
	}
	
	onStart(onStarted) {
		this.blink(onStarted,"start");
	}
	
	onStop(onFinished) {
		this.blink(onFinished,"stop");
	}
	
	blink(onDone,arg) {
		Logger.log("Circle8      blink "+arg);
		if (arg=="start" || arg=="stop") {
			var t=0;
			var duration = (arg=="start") ? 6000 : 1000;
			for(var id in this.hardware.elms) {
				var elm = this.hardware.elms[id];
				if (elm.type!="LED") continue;
				elm.dev.blink(250+t,50,duration,0,null);
				t+= (arg=="start") ? +10 : -10;
			}
			setTimeout(function() {
				app.clear();
			},duration+200);

			if (onDone) setTimeout(onDone,duration+300);
		}
		else {
			for(var id in this.hardware.elms) {
				var elm = this.hardware.elms[id];
				if (elm.type!="LED") continue;
				elm.dev.blink(
					arg.interval||250,
					arg.ratio||50,
					arg.duration||0,
					arg.cycles||3,
					null
				);
			}
		}
	}

	clear() {
		for(var id in app.hardware.elms) {
			var elm = app.hardware.elms[id];
			if (elm.type!="LED") continue;
			elm.dev.off();
		}		
	}
	
	onButtonChanged(id,cmd) {
		// let LED 0 blink
		app.hardware.elms["L0"].dev.blink(150,50,500,3);
	}
}
Circle.getApiDescription = function() {
	return [
		{	cmd:	"blink",
			effect:	"let all LEDs blink three times"
		},
	];
}
// =========================================================================================================
module.exports.Circle = Circle;
