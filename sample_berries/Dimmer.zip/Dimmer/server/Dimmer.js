"use strict";

const Logger 	= require("../../berry/utils/Logger.js").Logger;
const isMissing = require("../../berry/utils/Logger.js").isMissing;
const isPresent = require("../../berry/utils/Logger.js").isPresent;
const App 		= require("../../berry/server/App.js").App;

var app;

// =========================================================================================================

class Dimmer extends App {
	/*
		Dimmer handles the control logic for a momentary push button.
		The following is a rough semi-formal specification
		
		increment	=  -2%			// 50 steps
		lastValue	=  10%			// initial setting, only on startup
		minimum		=  10%
		maximum		= 100%
		tickTime    =  40 msec		// 2 seconds from dark to bright
		
		if (double click detected) {
			value=maximum
		}

		if (normal button down detected) 
			lastIncrement = increment= -lastIncrement			// change direction
			if value==0
				value=lastValue									// restore value
			else 			
				wasOn=true
			short pause
			repeat until "up" detected for every tickTime		// check continuously
				if "up" happened shortly after down				// short press/release action
					if wasOn
						value=0									// switch off 
				else
					lastValue = value = value+increment			// change value
				    if value>=maximum or value<=minimum			// reverse when reaching maximum or minimum 
						short pause
						lastIncrement=increment=-increment
	*/
	
	constructor(hardware,silent) {
		// called after loading the hardware definition
		// hardware elements are not yet available
		
		super(hardware,silent);
		
		// make instance available for functions which are invoked as callbacks
		app=this;
	}
	
	init() {
		// called after all hardware elements have been created

		this.button	= this.hardware.elms.but.dev;
		this.dimmer = this.hardware.elms.dimHW.dev;

		this.minimum		=  10;	// minimum duty cycle, typically this is not 0
		this.maximum		= 100;	// maximum duty cycle
		this.shortPressTime	= 200;	// times shorter than this will toggle the value, 
									// longer times will start dimming
		this.dimTickTime	= 66;	// time in msecs between two change steps
		this.lastValue		= 10;	// the last value stored (initially the minimum)
		this.increment		= -2;	// one step of change
		this.value			=  0;	// the current value of the dimmer
		this.dimming		= null;	// the dimming timer
		this.downTime		=  0;	// the moment when the button down event was detected
		this.turnStepsWait	= 10;	// at the turning point insert this number of do-nothing-steps
									// this makes it easier for the user to stop at the turning points
		this.turnStep		=  9;	// the current number of steps waited at the turning point
		this.beginStepsWait	=  4;	// before starting to dim wait for some steps
									// this makes it easier for the user to stop at the turning points
		this.beginning		= false;// true while we are waiting to begin
		this.beginStep		= 0;	// the current number of steps waited before beginning
		this.dblClickTime	= 200;	// two button downs within this time period are perceived as a double click
	}
	
	down() {
		// process a button-down event

		var my=app;
		if (!my.dimming) {
			Logger.log("Dimmer       down");

			// check for double click
			var now = new Date().getTime();
			if (now-my.downTime<my.dblClickTime) {
				my.value=my.lastValue=my.maximum;
				my.update();
				return;
			}

			my.wasOn=(my.value!=0);
			if(my.value == 0) {
				my.value=my.lastValue;
				my.update();
			}
			my.beginStep=0;
			my.beginning=true;
			my.increment=-my.increment;
			my.downTime=now;
			if (!my.dimming) clearInterval(my.dimming);
			// start the dimming process
			my.dimming=setInterval(app.down,my.dimTickTime);			
		}
		// wait for beginning if we are about to start
		if (my.beginStep<my.beginStepsWait) {
			my.beginStep++;
			return;
		}
		// wait at the turning points (except we just began)
		if (!my.beginning && (my.value<=my.minimum || my.value>=my.maximum)) {
			if (my.turnStep<my.turnStepsWait) {
				my.turnStep++;
				return;
			}
			else {
				if (my.value >= my.maximum) { my.value=my.maximum; my.increment = -(Math.abs(my.increment)); }
				if (my.value <= my.minimum) { my.value=my.minimum; my.increment = +(Math.abs(my.increment)); }
				my.turnStep=0;
			}
		}
		// change the current value
		my.lastValue = my.value = my.value + my.increment;
		my.beginning = false;		
		my.update();
		
	}

	up() {
		// process a button-up event
		
		var my=app;
		Logger.log("Dimmer       up");
		if (my.dimming) clearInterval(my.dimming);
		my.dimming=null;
		if (new Date().getTime() - my.downTime <= my.shortPressTime) {
			if (my.wasOn) {
				my.value=0;
				my.update();
			}
		}
	}

	update() {
		// change the PWDevice and implicitly) the LED driven by it
		app.dimmer.setDutyCycle(app.value*0.01);
	}
}
Dimmer.getApiDescription = function() {
	return [
		{	cmd:	"down",
			effect:	"simulate the control button being held down"
		},
		{	cmd:	"up",
			effect:	"simulate the control button being released"
		},
	];
}
// =========================================================================================================
module.exports.Dimmer = Dimmer;
